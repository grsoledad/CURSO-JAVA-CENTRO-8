package Interface;

import java.util.List;

import Entities.Vehiculo;

public interface I_Listar {
 
    List cargarVehiculos(List<Vehiculo> vehiculos);
   
    void recorrerLista(List<Vehiculo> vehiculos);

}
