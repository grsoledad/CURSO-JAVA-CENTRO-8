package TestVehiculo;

import java.util.ArrayList;
import java.util.List;

import Entities.Vehiculo;
import Utils.CargaVehiculos;

public class TestVehiculo {

    public static void main(String[] args) {

        List<Vehiculo> vehiculos = new ArrayList();
   
        CargaVehiculos inventario= new CargaVehiculos();

        System.out.println("INVENTARIO:\n");
            inventario.cargarVehiculos(vehiculos);
            inventario.recorrerLista(vehiculos);
    }    
}

/*
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */