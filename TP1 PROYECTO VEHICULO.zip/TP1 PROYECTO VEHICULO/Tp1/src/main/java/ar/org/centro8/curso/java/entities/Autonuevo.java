package ar.org.centro8.curso.java.entities;

public class Autonuevo extends Vehiculo{

           
    public Autonuevo(String marca, String modelo, String color, double precio, String marcaRadio, int potencia) {
        super(marca, modelo, color, precio);
        super.radio = new Radio(marcaRadio, potencia);
    }
       
    public Autonuevo(String marca, String modelo, String color, String marcaRadio, int potencia) {
        super(marca, modelo, color);
        super.radio = new Radio(marcaRadio, potencia);
    }

}
