package ar.org.centro8.curso.java.entities;

import lombok.Getter;
import lombok.ToString;

@ToString
@Getter

public abstract class Vehiculo {

        String marca;
        String modelo;
        String color;
        double precio;
        Radio radio;
    

    /**
    * CONSTRUCTOR CON PRECIO
    */
    public Vehiculo(String marca, String modelo, String color, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        
    }
    /** 
     * CONSTRUCTOR SIN PRECIO
    */
    public Vehiculo(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    /**
     * 
     * CONSTRUCTOR CON UNA RADIO PARA CADA VEHÍCULO CON PRECIO
     */
        public Vehiculo(String marca, String modelo, String color, double precio, String marcaRadio, int potencia) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        this.radio = new Radio(marcaRadio, potencia);
    }
     

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    
    public void setRadio(String marcaRadio, int potencia) {
            radio = new Radio(marcaRadio, potencia);
    }
    
}

