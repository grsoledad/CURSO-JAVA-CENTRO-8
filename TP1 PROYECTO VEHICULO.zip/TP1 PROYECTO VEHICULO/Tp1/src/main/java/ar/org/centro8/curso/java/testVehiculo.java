package ar.org.centro8.curso.java;

import ar.org.centro8.curso.java.entities.AutoClasico;
import ar.org.centro8.curso.java.entities.Autonuevo;
import ar.org.centro8.curso.java.entities.Bondis;
import ar.org.centro8.curso.java.entities.Radio;

public class testVehiculo {

    public static void main(String[] args) {
        Radio rad1=new Radio("Suono", 50);
        Radio rad2=new Radio("Panacom", 40);
        Radio rad3=new Radio(" Noblex", 50);
        Radio rad4=new Radio("X-View", 45);
        Radio rad5=new Radio("Suono", 50);
        Radio rad6=new Radio("Nakamichi", 50);
        Radio rad7=new Radio("Nakamichi", 50);
        Radio rad8=new Radio("Nakamichi", 50);
        Radio rad9=new Radio("Panacom", 50);
        Radio rad10=new Radio("X-View", 45);

        //System.out.println("-- radio 6 --");
        //System.out.println(rad6);

        //auto sin precio
        Autonuevo auton1= new Autonuevo("Renault", "Logan", "Gris", "Panacom", 40);    
        System.out.println("-- auton1 --");
        System.out.println(auton1);
        System.out.println("Agregamos un precio al Renault Logan");
        auton1.setPrecio(150000);
        System.out.println(auton1);
        
       
        System.out.println("*************************************************");
        //auto con precio
        Autonuevo auton2= new Autonuevo("Ford", "Fiesta", "Rojo", 80000, "X-View", 45);
        System.out.println(" -- auto 2 --");
        System.out.println(auton2);
        System.out.println("A continuación se aumenta el precio a la unidad Ford Fiesta");
        auton2.setPrecio(120000);
        System.out.println(auton2);


        System.out.println("*************************************************");
        //bondi con radio y con precio
        Bondis bondi1= new Bondis("Mercedes Benz", "Marcopolo", "blanco", 2500000, "Panacom", 50);
        System.out.println(" -- bondi 1 --");
        System.out.println(bondi1);
        System.out.println("A continuación se hace un cambio de radio");
        bondi1.setRadio("Nakamichi", 50);
        System.out.println(bondi1);

        System.out.println("*************************************************");
        //bondi con radio y sin precio
        Bondis bondi2= new Bondis("Volkswagen", "17-240", "verde", "Noblex", 50);
        System.out.println(" -- bondi 2 --");
        System.out.println(bondi2);

        
        System.out.println("*************************************************");
        //bondi sin radio y con precio
        Bondis bondi3= new Bondis("Mercedes Benz", "500", "blanco", 500000);
        System.out.println(" -- bondi 3 --");
        System.out.println(bondi3);

        System.out.println("*************************************************");
        //bondi sin radio y sin precio
         Bondis bondi4=new Bondis("Scania", "K310", "negro");
         System.out.println(" -- bondi 4 --");
         System.out.println(bondi4);
     
         System.out.println("*************************************************");
         //auto clásico con radio y con precio
         AutoClasico autoc1= new AutoClasico("Ford", "Mustang", "azul", 85000, "Suono", 50);
         System.out.println(" -- auto clásico 1 --");
         System.out.println(autoc1);

         System.out.println("*************************************************");
         //auto clásico con radio y sin precio
         AutoClasico autoc2= new AutoClasico("Corvette", "Stingray Tip Top At", "rojo", "Nakamichi", 50);
         System.out.println(" -- auto clásico 2 --");
         System.out.println(autoc2);
         System.out.println("A continuación hacemos un cambio de radio al Corvette y  le agregamos el precio de venta");
         autoc2.setRadio("X-View", 45);
         autoc2.setPrecio(50000);
         System.out.println(autoc2);
        


         System.out.println("*************************************************");
         //auto clásico sin radio y con precio
         AutoClasico autoc3= new AutoClasico("Austin mini", "Austin morris 1000","rojo", 45000);
         System.out.println(" -- auto clásico 3 --");
         System.out.println(autoc3);
         autoc3.setPrecio(55000);
         System.out.println(autoc3);
         System.out.println("Se le agrega una radio al Austin mini");
         autoc3.setRadio("Nakamichi", 50);
         System.out.println(autoc3);

         System.out.println("*************************************************");
         //auto clasico sin radio y sin precio
         AutoClasico autoc4= new AutoClasico("Cadillac", "deville 1961", "celeste");
         System.out.println(" -- auto clasico 4 --");
         System.out.println(autoc4);    

    } 
}
