package Utils;

import java.util.List;

import Entities.Auto;
import Entities.Moto;
import Entities.Vehiculo;
import Interface.I_Listar;

public class CargaVehiculos implements I_Listar {

    @Override
    public List cargarVehiculos(List<Vehiculo> vehiculos) {

         vehiculos.add(new Auto ("Peugeot", "206", "4 ptas.", 200000));
         vehiculos.add(new Moto("Honda", "Titan", "125c", 60000));
         vehiculos.add(new Auto("Peugeot", "208", "5 ptas", 250000));
         vehiculos.add(new Moto("Yamaha", "YBR", "160c", 80500.50));
        
         return vehiculos;    
    } 

    @Override
    public void recorrerLista(List<Vehiculo> vehiculos) {
        vehiculos.forEach(System.out::println);
        
    }

    
    

    
    
    
    
  
    
    
        
    
    
    
    
}
