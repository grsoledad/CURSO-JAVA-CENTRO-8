package TestVehiculo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import Entities.Vehiculo;
import Utils.CargaVehiculos;

public class TestVehiculo {

    public static void main(String[] args) {

        List<Vehiculo> vehiculos = new ArrayList();
   
        CargaVehiculos inventario= new CargaVehiculos();

        System.out.println("INVENTARIO:\n");
            inventario.cargarVehiculos(vehiculos);
            inventario.recorrerLista(vehiculos);

            System.out.println("====================================================================");
            System.out.println("Vehículo más caro");

            double precioMax= vehiculos
            
                    .stream()
                    .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                    .get()
                    .getPrecio();
                vehiculos
                    .stream()
                    .filter(v->v.getPrecio()==precioMax)
                    .forEach(v->System.out.println(v.getMarca()+ " "+ v.getModelo()));
            
            System.out.println("====================================================================");
            System.out.println("Vehículo más barato");
            double precioMin= vehiculos
            
                    .stream()
                    .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                    .get()
                    .getPrecio();
                vehiculos
                    .stream()
                    .filter(v->v.getPrecio()==precioMin)
                    .forEach(v->System.out.println(v.getMarca()+ " "+ v.getModelo()));

            System.out.println("=====================================================================");
            System.out.println("Vehículo que contiene en el modelo la letra 'Y'");

                vehiculos
                    .stream()
                    .filter(v->v.getModelo().toUpperCase().contains("Y"))
                    .forEach(v->System.out.println(v.getMarca()+ " "+ v.getModelo()+ " "+v.getPrecio()));

            System.out.println("===============================================================");
            System.out.println("Vehículo ordenados de mayor a menor");

                vehiculos
                     .stream()
                     .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                     .forEach(v->System.out.println(v.getMarca()+ " "+ v.getModelo()));

            System.out.println("====================================================================");
            System.out.println("Vehículos ordenados por orden natural");
                
                vehiculos
                             .stream()
                             .sorted()
                             .forEach(System.out::println);

    }    
}


















