package Entities;

import java.text.DecimalFormat;

public class Auto extends Vehiculo {

    private String puertas;
  
    public Auto(String marca, String modelo, String puertas, double precio) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }
    DecimalFormat df= new DecimalFormat("#.00");
    @Override
    public String toString() {
        return "marca:" + marca + "//modelo:" + modelo + "//puertas:" + puertas + "//precio:" + df.format(precio);
       
    }
    public String getPuertas() {
        return puertas;
    }
    public void setPuertas(String puertas) {
        this.puertas = puertas;
    }
  
}
