package ar.org.centro8.curso.java.entities;

public final class Bondis extends Vehiculo {

    //BONDIS CON RADIO Y CON PRECIO
    public Bondis(String marca, String modelo, String color, double precio, String marcaRadio, int potencia) {
        super(marca, modelo, color, precio);
        super.radio = new Radio(marcaRadio, potencia);
    }

    //BONDIS CON RADIO Y SIN PRECIO
    public Bondis(String marca, String modelo, String color, String marcaRadio, int potencia) {
        super(marca, modelo, color);
        super.radio = new Radio(marcaRadio, potencia);
    }
    //BONDIS SIN RADIO Y CON PRECIO
    public Bondis(String marca, String modelo, String color, double precio) {
        super(marca, modelo, color, precio);
        
    }
    //BONDIS SIN RADIO Y SIN PRECIO
    public Bondis(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }
}
   


    

    


