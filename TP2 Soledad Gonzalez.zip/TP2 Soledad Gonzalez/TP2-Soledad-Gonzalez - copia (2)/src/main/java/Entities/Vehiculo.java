package Entities;

public abstract class Vehiculo implements Comparable<Vehiculo>{
    protected String marca;
    protected String modelo;
    protected double precio;
   
    public Vehiculo(String marca, String modelo, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Marca:" + marca + ", Modelo:" + modelo + ", Precio:" + precio;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public int compareTo(Vehiculo para) {
       String thisVehiculo=this.getMarca()+","+this.getModelo()+","+this.getPrecio();
       String paraVehiculo=para.getMarca()+","+para.getModelo()+","+para.getPrecio();
       return thisVehiculo.compareTo(paraVehiculo);
    }
}
